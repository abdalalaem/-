<?php
$info = json_decode(file_get_contents("info.json"),1);
$token = $info['token'];
define('API_KEY',$token);
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch,32|128|265));
}else{
return json_decode($res);
}
}
function SendVoice($chat_id,$voice,$caption=null,$parse_mode="MARKDOWN",$duration=null,$reply_to_message_id=null,$reply_markup=null){
	return bot('sendVoice',[
	'chat_id'=>$chat_id,
	'voice'=>$voice,
	'caption'=>$caption,
	'parse_mode'=>$parse_mode,
	'duration'=>$duration,
	'disable_notification'=>false,
	'reply_to_message_id'=>$reply_to_message_id,
	'reply_markup'=>$reply_markup
	]);
}
function SendMessage($chat_id,$text,$parse_mode="MARKDOWN",$disable_web_page_preview=true,$reply_to_message_id=null,$reply_markup=null){
    return bot('sendMessage',[
	'chat_id'=>$chat_id,
	'text'=>$text,
	'parse_mode'=>$parse_mode,
	'disable_web_page_preview'=>$disable_web_page_preview,
	'disable_notification'=>false,
	'reply_to_message_id'=>$reply_to_message_id,
	'reply_markup'=>$reply_markup
	]);
}
function SendPhoto($chat_id,$photo,$caption=null,$parse_mode="MARKDOWN",$reply_to_message_id=null,$reply_markup=null){
	return bot('sendPhoto',[
	'chat_id'=>$chat_id,
	'photo'=>$photo,
	'caption'=>$caption,
	'parse_mode'=>$parse_mode,
	'disable_notification'=>false,
	'reply_to_message_id'=>$reply_to_message_id,
	'reply_markup'=>$reply_markup
	]);
}
function SendAudio($chat_id,$audio,$caption=null,$parse_mode="MARKDOWN",$duration=null,$performer=null,$title=null,$thumb=null,$reply_to_message_id=null,$reply_markup=null){
	return bot('sendAudio',[
	'chat_id'=>$chat_id,
	'audio'=>$audio,
	'caption'=>$caption,
	'parse_mode'=>$parse_mode,
	'duration'=>$duration,
	'performer'=>$performer,
	'title'=>$title,
	'thumb'=>$thumb,
	'disable_notification'=>false,
	'reply_to_message_id'=>$reply_to_message_id,
	'reply_markup'=>$reply_markup
	]);
}
function SendDocument($chat_id,$document,$thumb=null,$caption=null,$parse_mode="MARKDOWN",$reply_to_message_id=null,$reply_markup=null){
	return bot('sendDocument',[
	'chat_id'=>$chat_id,
	'document'=>$document,
	'thumb'=>$thumb,
	'caption'=>$caption,
	'parse_mode'=>$parse_mode,
	'disable_notification'=>false,
	'reply_to_message_id'=>$reply_to_message_id,
	'reply_markup'=>$reply_markup
	]);
}
function SendVideo($chat_id,$video,$duration=null,$width=null,$height=null,$thumb=null,$caption=null,$parse_mode="MARKDOWN",$reply_to_message_id=null,$reply_markup=null,$supports_streaming=null){
	return bot('sendVideo',[
	'chat_id'=>$chat_id,
	'video'=>$video,
	'duration'=>$duration,
	'width'=>$width,
	'height'=>$height,
	'thumb'=>$thumb,
    'caption'=>$caption,
	'parse_mode'=>$parse_mode,
	'supports_streaming'=>$supports_streaming,
	'disable_notification'=>false,
	'reply_to_message_id'=>$reply_to_message_id,
	'reply_markup'=>$reply_markup
	]);
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id ?? $update->callback_query->message->chat->id;
$from_id = $message->from->id ?? $update->callback_query->from->id;
$text = $message->text;
$message_id = $message->message_id ?? $update->callback_query->message->message_id;
$name = $message->from->first_name ?? $update->callback_query->from->first_name;
$username = $message->from->username ?? $update->callback_query->from->username;
$data = $update->callback_query->data;
$start ="‹ : اهلا بك عزيزي : #name \n -  يمكنك التحميل من عدة مواقع والاستماع اليها في اي وقت .  \n ‹ : المواقع المدعومه : ( يوتيوب، انستكرام، فيسبوك، تويتر، تيك ، تيك ، ولخ ) . ";

if(preg_match("/(.*?)tiktok(.*?)/",$text)){
SendMessage($chat_id,"• انتضر قليل");
$api = json_decode(file_get_contents("https://iiraq.tk/api/aiptik.php?url=".$text),1);
$caption = $api["desc"];
$caption = $api["desc"];
SendVideo($chat_id,curl_file_create($api["links"][1]["a"],"type","v.mp4"),null,null,null,null,$caption);
SendAudio($chat_id,curl_file_create($api["links"][1]["a"],"type","v.mp3"),$caption);
SendAudio($chat_id,curl_file_create($api["links"][1]["a"],"type","v.ogg"),$caption);
    
}
$me = bot('getme',['bot'])->result->username;
$caption = "• @$me";

if($text == "/start"){
SendMessage($chat_id,"$start" ,"Markdown",true,$message_id);
}
if(preg_match('/(http(s|):|)\/\/(www\.|)yout(.*?)\/(embed\/|watch.*?v=|)([a-z_A-Z0-9\-]{11})/i', $text) or preg_match('/(.*?)fb(.*?)/',$text) or preg_match('/(.*?)twitter(.*?)/',$text)){
$api =json_decode(file_get_contents('https://iiraq.tk/api/Sohmo.php?url='.$text),true);

$title = $api["meta"]["title"];
$duration = $api["meta"]["duration"];
$hosting = $api["hosting"];
$hmothme = "•︙عنوان الرابط : $title\n•︙مدة الرابط : $duration\n•︙نوع الرابط : $hosting";
SendMessage($chat_id,$hmothme,"Markdown",true,$message_id);
SendMessage($chat_id,"• انتضر قليل");
$api =json_decode(file_get_contents('https://iiraq.tk/api/Sohmo.php?url='.$text),true);
$x = curl_file_create($api["url"][1]["url"],"type","$me.mp4");
SendVideo($chat_id,$x,null,null,null,null,$caption);
$x1 = curl_file_create($api["url"][1]["url"],"type","$me.mp4");
SendAudio($chat_id,$x1,$caption);
$x2 = curl_file_create($api["url"][1]["url"],"type","$me.voice");
SendVoice($chat_id,$x2,$caption);
#///#////
$x3 = curl_file_create($api["url"][0]["url"],"type","$me.mp4");
SendVideo($chat_id,$x3,null,null,null,null,$caption);
$x4 = curl_file_create($api["url"][0]["url"],"type","$me.mp4");
SendAudio($chat_id,$x4,$caption);
$x5 = curl_file_create($api["url"][0]["url"],"type","$me.voice");
SendVoice($chat_id,$x5,$caption);
}
$api = json_decode(file_get_contents("https://iiraq.tk/api/instagram.php?url=".$text));
if(preg_match("/(.*?)tv(.*?)/",$text) or preg_match("#reel#",$text)){
SendDocument($chat_id,$api->url[0]->url);
}else{
for($i=0;$i<count($api);$i++){
if(preg_match("#.jpg#",$api[$i]->url[0]->url) or preg_match("/(.*?).png(.*?)/",$api[$i]->url[0]->url)){
SendPhoto($chat_id,$api[$i]->url[0]->url);
}else{
SendVideo($chat_id,$api[$i]->url[0]->url);
}
}
}
if(preg_match("/(.*?)pin(.*?)/",$text)){
$api =json_decode(file_get_contents('https://iiraq.tk/api/pinterest.php?url='.$text),true);
Senddocument($chat_id,$api["url"]);
}